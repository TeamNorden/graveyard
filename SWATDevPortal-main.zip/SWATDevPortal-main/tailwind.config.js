module.exports = {
	darkMode: "class",
	content: [
		"./src/pages/**/*.{js,ts,jsx,tsx}",
		"./src/util/**/*.{js,ts,jsx,tsx}",
		"./src/components/**/*.{js,ts,jsx,tsx}",
	],
	theme: {
		extend: {
			fontFamily: {
				montserrat: ["Montserrat"],
				inter: ["Inter"],
			},
			colors: {
				dank: {
					100: "#ffffff",
					200: "#cccccc",
					300: "#000000",
					400: "#808080",
					500: "#666666",
					600: "#4a4a4a",
				},
				dark: {
					100: "#5c5c5c",
					200: "#424242",
					300: "#212121",
					400: "#000000",
				},
				light: {
					100: "#ffffff",
					200: "#FBFFFB",
					300: "#eafcf1",
					400: "#F0FBF0",
					500: "#ececec",
					600: "#7f8a7f",
				},
			},
		},
	},
	plugins: [require("@tailwindcss/line-clamp")],
};
