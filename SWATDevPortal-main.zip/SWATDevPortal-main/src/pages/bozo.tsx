import { useRouter } from "next/router";
import { userInfo } from "os";
import Button from "../components/ui/Button";
import { PageProps } from "../types";
import { NextIronRequest, withSession } from "../util/session";

export default function Bozo({}: PageProps, req: NextIronRequest) {
	const router = useRouter();

	return (
		<div className="w-full h-screen flex justify-center items-center text-center">
			<div className="flex flex-col space-y-2">
				<div className="text-dank-300 text-6xl font-bold font-montserrat">
					LOOOOOOOOL YOU ARE A TRUE BOZO.
				</div>
				<div className="font-montserrat font-bold text-dark-400 dark:text-white">
					real talk tho, error code 403 unauthorized, try login or smth if u think u have access. if you dont, leave the site rn.
				</div>
				<Button
					size="medium"
					variant="primary"
					onClick={() => router.push("/")}
				>
					Go Home
				</Button>
			</div>
		</div>
	);
}
