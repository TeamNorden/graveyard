![SWAT Banner](assets/SWAT_BANNER_GRADIENT_1920x750.png)
# SWAT

This is SWAT Helper, the helper bot to assist the Bot Admins and Bot Development Staff in their ability to manage the bot, manage users and analyze every aspect of the bot and all related services.
To keep updated with the main bot (SWAT) and it's development, join the [Support Server](#support).

## Contributors
@Codeize
- [GitHub](https://github.com/Codeize)
- [Twitter](https://twitter.com/Codeize)

## License
At a high level, here's the cans and cannots of the TeamNorden x SWAT Services license.

YOU MAY:

- (a) View the code.

- (b) Edit the code without sharing it.

- (c) Privately run the code without sharing it.

YOU MAY NOT, BUT NOT LIMITED TO:

- (a) Share or distribute the code in any way, including;

- (b) Hosting a modified or unmodified version of the code for anyone other than Yourself to use.

This is not an exhaustive list of the terms of use for SWAT, and exemptions can be made at the sole discretion of TeamNorden.
If you are interested in this or have any additional queries please [read the license fully](https://github.com/TeamNorden/legal/blob/main/LICENSE.md) or [join our support server](#support)

## Contributing
Currently, we do not endorse the self hosting of SWAT Helper.

However if you have any technical know-how, this will be a breeze to self host.

## Credits

[SwitchbladeBot](https://github.com/SwitchbladeBot) for allowing the use of their widget service.

[xPolar](https://github.com/xPolar) for providing the base of the bot.

[Geek](https://github.com/GamingGeek) for providing the [paste bin service](https://h.inv.wtf).

## Support
[![widget](https://invidget.switchblade.xyz/854739172580655134)](https://discord.gg/7syTGCkZs8)
