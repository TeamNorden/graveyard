import { load } from "dotenv-extended";
import { ShardingManager } from "discord.js";
import Logger from "../lib/classes/Logger";

load();

const manager = new ShardingManager("./dist/src/bot/bot.js", {
	token: process.env.TOKEN,
});

Logger.info(`Starting SWAT Helper.`);


manager.spawn({
	timeout: -1
});

manager.on("shardCreate", (shard) => {
	Logger.info(`Starting Shard ${shard.id}.`);
	if (shard.id + 1 === manager.totalShards) {
		shard.once("ready", () => {
			setTimeout(() => {
				Logger.info("All shards are online and ready!");
			}, 200);
		});
	}
});
