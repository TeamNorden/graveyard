import { Interaction, GuildMember, MessageSelectMenu } from "discord.js";
import EventHandler from "../../../lib/classes/EventHandler";

export default class InteractionCreate extends EventHandler {
	override async run(interaction: Interaction) {
		// @ts-ignore
		if (this.client.mongoStatus === "1")
			// @ts-ignore
			return interaction.reply(
				this.client.functions.generateErrorMessage(
					{
						title: "Not Ready",
						description: "I'm not ready yet, please try again in a moment!"
					},
					true
				)
			);
		if (interaction.isCommand()) {
			this.client.stats.commandsRun++;
			return this.client.slashCommandHandler.handleCommand(interaction);
		} else if (interaction.isButton())
			return this.client.buttonHandler.handleButton(interaction);
		else if (interaction.isSelectMenu()) {
			const { customId, values, member } = interaction
			if (customId === "auto_roles" && member instanceof GuildMember) {
				const component = interaction.component as MessageSelectMenu;
				const removed = component.options.filter((option) => {
					return !values.includes(option.value);
				})

				for (const id of removed) {
					member!.roles.remove(id.value);
				}

				for (const id of values) {
					member!.roles.add(id)
					return interaction.reply(
						this.client.functions.generateSuccessMessage({
							title: "Auto Role Added",
							description: `Added the role <@&${id}>!`
						})
					);
				}
			}
		}
		const error = new Error("Invalid Interaction: Never seen this before.");
		this.client.logger.error(error);
		this.client.logger.sentry.captureWithInteraction(error, interaction);
		// @ts-ignore
		return interaction.reply(
			this.client.functions.generateErrorMessage(
				{
					title: "Invalid Interaction",
					description: "I've never seen this type of interaction"
				},
				true
			)
		);
	}
}
