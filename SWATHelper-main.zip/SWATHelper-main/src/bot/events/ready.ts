import EventHandler from "../../../lib/classes/EventHandler";

export default class MessageCreate extends EventHandler {
	override async run() {
		const stats = await this.client.fetchStats();
		this.client.logger.info(
			`Logged in as ${this.client.user?.tag} [${this.client.user?.id}] | ${stats}`
		);

	}
}
