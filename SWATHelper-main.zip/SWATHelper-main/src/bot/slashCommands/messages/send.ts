import { CommandInteraction, MessageActionRow, MessageSelectMenu, MessageSelectOptionData } from "discord.js";
import SlashCommand from "../../../../lib/classes/SlashCommand";
import BetterClient from "../../../../lib/extensions/BetterClient";

export default class Send extends SlashCommand {
	constructor(client: BetterClient) {
		super("send", client, {
			description: `yuh.`,
			permissions: ["MANAGE_MESSAGES"],
			clientPermissions: ["READ_MESSAGE_HISTORY", "MANAGE_MESSAGES"],
            options: [
                {
                    name: "channel",
                    description: "The channel in which you would like to send/edit a message.",
                    type: "CHANNEL",
                    required: true
                },
                {
                    name: "content",
                    description: "The message content.",
                    type: "STRING",
                    required: true
                },
                {
                    name: "id",
                    description: "The ID of the message you wish to edit, if applicable.",
                    type: "STRING",
                    required: false
                }
            ]
		});
	}

	override async run(interaction: CommandInteraction) {
        const channel = interaction.options.getChannel("channel");
        const id = interaction.options.getString("id");
        const content = interaction.options.getString("content");

        if (!channel || channel.type !== "GUILD_TEXT") {
            return interaction.reply("The channel must be a text channel!");
        }

        let targetMessage
        if(id) {
            try {
                targetMessage = await channel.messages.fetch(id!, {
                cache: true
                })
            } catch (e) {
                return interaction.reply("The message seems to be invalid!");
            }

            if (targetMessage.author.id !== this.client.user!.id) {
                return interaction.reply("The message must be sent by me!");
            }

            targetMessage.edit(content!);
        } else {
            targetMessage = await channel.send(content!);
        }

		return interaction.reply(
			this.client.functions.generateSuccessMessage(
				{
					title: "Message Sent!",
					description: `[The message was sent, or edited if applicable](${targetMessage?.url}.)`,
				},
				[],
				interaction.options.getBoolean("silent") || false
			)
		);
	}
}