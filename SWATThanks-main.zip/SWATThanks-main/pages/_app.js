import '../styles/globals.css'

function Thanks({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default Thanks
