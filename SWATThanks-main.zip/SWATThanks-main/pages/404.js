import Custom404 from '../components/404'

const custom404 = () => {
  return (
    <>
      <Custom404 />
    </>
  )
}

export default custom404
