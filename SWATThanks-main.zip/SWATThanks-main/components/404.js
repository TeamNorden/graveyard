export default function Custom404() {
  return <h1 className="fourohfour">404 - Page Not Found</h1>
}
